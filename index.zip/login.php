<?php
session_start();

$_SESSION['token'] = $_POST['token'];

?>