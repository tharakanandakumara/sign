<?php
// This file was auto-generated from sdk-root/src/data/quicksight/2018-04-01/paginators-1.json
return [ 'pagination' => [],];
