<?php
// This file was auto-generated from sdk-root/src/data/shield/2016-06-02/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-east-1', 'testCases' => [ [ 'operationName' => 'ListAttacks', 'input' => [], 'errorExpectedFromService' => false, ], ],];
