<?php
// This file was auto-generated from sdk-root/src/data/entitlement.marketplace/2017-01-11/paginators-1.json
return [ 'pagination' => [],];
