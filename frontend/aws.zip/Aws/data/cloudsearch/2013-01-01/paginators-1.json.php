<?php
// This file was auto-generated from sdk-root/src/data/cloudsearch/2013-01-01/paginators-1.json
return [ 'pagination' => [ 'DescribeAnalysisSchemes' => [ 'result_key' => 'AnalysisSchemes', ], 'DescribeDomains' => [ 'result_key' => 'DomainStatusList', ], 'DescribeExpressions' => [ 'result_key' => 'Expressions', ], 'DescribeIndexFields' => [ 'result_key' => 'IndexFields', ], 'DescribeSuggesters' => [ 'result_key' => 'Suggesters', ], ],];
