<?php
// This file was auto-generated from sdk-root/src/data/mturk-requester/2017-01-17/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-east-1', 'testCases' => [ [ 'operationName' => 'GetAccountBalance', 'input' => [], 'errorExpectedFromService' => false, ], ],];
